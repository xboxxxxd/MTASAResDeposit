function PlateText(thePlayer,commandName,text)
	local Vehicle = getPedOccupiedVehicle(thePlayer)
	if Vehicle then
		if text then
			setVehiclePlateText( Vehicle, text )
		else
			outputChatBox("Musisz wprowadzic tekst twojej tablicy np. PC 1707.",thePlayer)
		end
	else
		outputChatBox("Musisz byc w pojezdzie.",thePlayer)
	end
end
addCommandHandler("setplate",PlateText)