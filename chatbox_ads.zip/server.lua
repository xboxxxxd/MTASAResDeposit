function outputTopChat(text, to, r, g, b)
	if text then else return false end
	triggerClientEvent(to or root, "outputTopChat", to or root, text, r or 255, g or 255, b or 255)
end