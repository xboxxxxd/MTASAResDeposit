function colour (thePlayer)
	local chatterName = getPlayerName (thePlayer)
		outputTopChat ("* " ..chatterName.. "#ffffff countdown ", getRootElement(), 255, 255, 0, true )
	end
addCommandHandler("countdown", colour)

function countdownRec (count)
      if (count > 0) then
          outputTopChat(tostring(count), getRootElement(), 255, 255, 0)
          setTimer(countdownRec, 1000, 1, count-1)
      else
          outputTopChat("Go Go Go!!!", getRootElement(), 255, 255, 0)
      end
end

function countdown()
      countdownRec(3)
end
addCommandHandler("countdown", countdown)