local root = getRootElement()
 
addEventHandler("onPlayerLogin", root,
  function()
  outputTopChat("#0075eb[RHD]" getPlayerName( source ):gsub( '#%x%x%x%x%x%x', '' "  Has Logged In To MOGA", root,255,255,255,true