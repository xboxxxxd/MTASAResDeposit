--------------------------------------------------------------------
--* Command vh respawn system *-------------------------------------
--* main_s.lua *----------------------------------------------------
--* Made by kimmis *------------------------------------------------
--* Do not fuckin remove this box *---------------------------------
--------------------------------------------------------------------

function respawn()
local accountname = getAccountName (getPlayerAccount(source))
if isObjectInACLGroup ( "user." .. accountname, aclGetGroup ( "Moderator" ) ) then
outputChatBox("***Respawning ALL Empty Vehicles In 10 Secs - Get IN your CAR to KEEP it***")
setTimer(function ()
local vehicles = getElementsByType ( "vehicle" ) 
for k, vehicle in ipairs ( vehicles ) do
if checkEmpty( vehicle ) then
local seats = getVehicleMaxPassengers(vehicle)
resetVehicleIdleTime ( vehicle ) 
respawnVehicle ( vehicle )
end
end
end, 10000, 1)
end 
end
addEvent( "respawn", true )
addEventHandler( "respawn", getRootElement(), respawn )

function checkEmpty( vehicle )
local passengers = getVehicleMaxPassengers( vehicle )
if type( passengers ) == 'number' then
for seat = 0, passengers do
if getVehicleOccupant( vehicle, seat ) then
return false
end
end
end
return true
end

