function triggerRespawn()
triggerServerEvent ( "respawn", getLocalPlayer() ) 
end
addCommandHandler("vhrespawn",triggerRespawn)