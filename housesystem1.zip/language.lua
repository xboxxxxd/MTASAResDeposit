CloseButton = "Close"

--// window 1 Home
BuyButton = "Buy"
SaleButton = "Sale"
AddPlayerButton = "Add Player"
EnterButton = "Enter"
TourButton = "Tour"
BankButton = "Bank"

Pricelabel = "Price : $"
Ownerlabel = "Owner :"
IDlabel = "ID : "
Datelabel = "Date of Made :"
Madeoflabel = "Made of :"
Namelabel = "Name :"
ForSalelabel = "For Sale :"
Yeslabel = "Yes"
Nolabel = "No"

--// window 2 Add Player
AddWindow = "Add Player"
AddButton = "Add"
RemoveButton = "Remove"
AccountColumn = "Account"
Accountlabel = "Account Name :"

--// window 3 Bnak
BankWindow = "Bank House"
MoneyLabel = "Money : $"
WithdrawButton = "Withdraw Money"
DepositButton = "Deposit Money"

--// window 4 Control Panel
ControlWindow = "Control Panel"
IDColumn = "ID"
OwnerColumn = "Owner"
PriceColumn = "Price"
ExitColumn = "Exit Position"
EnterColumn = "Enter Position"
InteriorColumn = "Interior"
DimensionColumn = "Dimension"