-- The sound loops independently
addEventHandler( "onClientResourceStart", getResourceRootElement( getThisResource()),
	function()
local desusound =playSound3D("1.wav",1089.6999511719,-1965.5,59.200000762939, true)
setSoundVolume(desusound,1.8)
setSoundMaxDistance(desusound, 50)
    end
	           )
