function panelInfo ()
        ventana1 = guiCreateWindow(0, 0, 1280, 716, "[MOGA] Rules", false)
        guiWindowSetSizable(ventana1, false)
        guiSetAlpha(ventana1, 1.00)

        cerrar = guiCreateButton(9, 690, 1261, 20, "F9 - To Open/Close", false, ventana1)
        guiSetProperty(cerrar, "NormalTextColour", "FFAAAAAA")
        label1 = guiCreateLabel(19, 70, 29, 15, "[MOGA]/[MOGAHQ]", false, ventana1)
        guiSetFont(label1, "default-bold-small")
        memo1 = guiCreateMemo(0.01, 0.13, 0.16, 0.40, "[MOGAHQ]Jack/ssmoke(Server Owner)\n[MOGAHQ]Mr.Worm(co-owner)\n[MOGAHQ]Mr.Spoty(Scripter)\n[MOGAHQ]Sherman\n[MOGAHQ]RealG\n[MOGAHQ]Freak\n[MOGAHQ]SnDAjj\n[MOGA]Dolan\n[MOGA]Hakim", true, ventana1)
        guiMemoSetReadOnly(memo1, true)
        label2 = guiCreateLabel(257, 70, 101, 15, "Rules for the players", false, ventana1)
        guiSetFont(label2, "default-bold-small")
        memo2 = guiCreateMemo(240, 90, 253, 285, "The HQ team hereby declare that these rules apply to all players that join this server.\n\n1. All players on this server shall be treated equally in equal circumstances. Discrimination on the grounds of religion, belief, political opinion,\n race, or sex or on any other grounds whatsoever shall not be permitted.\n\n1.2. Acting against this rule will cause the admins to take action against you.\n\n2. We neither appreciate excessive use of insulting language nor do we take action against it. Freedom of speech is given to everyone.\n\n3. Excessive spawn-camping and killing in front of spawn areas will lead to a kick and after multiple abuses to a long-term ban\n\n4. Dont be mad about getting killed.\n\n5. We dont need more admins. If we have the need for new members we announce it.\n\n6. Advertising other servers is not allowed.\n7. The players have to follow the admins instructions. If an admin acts against the rules the players can report it in the chat with: /report\n\n8. An admin can only be revoked from its duty with a constructive vote of no confidence through the MOGA-HQ Team.\n\n9. Trolling of any kind is not allowed. \n\n10.If you see an admin abusing his powers it's up to you to report it with proof in the forums. (mtamoga.enjin.com)", false, ventana1)
        guiMemoSetReadOnly(memo2, true)
        memo3 = guiCreateMemo(492, 90, 253, 285, "1. If a player acts against the rules, he has to get frozen first and confronted with his abuse. If its impossible to bring the player to its senses the ban follows.\n\n2. If a ban is not assigned with a reason visible in the ban list the ban will be revoked by the MOGA-HQ Team.\n\n3. Banning or kicking because of personal reasons is not allowed.\n\n4. Players who advertise other servers gets instant banned\n\n", false, ventana1)
        guiMemoSetReadOnly(memo3, true)
        label3 = guiCreateLabel(507, 70, 178, 15, "Rules for the admins", false, ventana1)
        guiSetFont(label3, "default-bold-small")
        label6 = guiCreateLabel(14, 665, 65, 15, "[MOGA]Motor sports!!!!", false, ventana1)
        guiSetFont(label6, "default-bold-small")    

        showCursor (true)
		addEventHandler ("onClientGUIClick", cerrar, cerrar1, false)

end
bindKey ("F9", "down", panelInfo)

function cerrar1 ()
showCursor (false)
outputChatBox ( "-==-F9 Rules/Staff-==-" )
guiSetVisible (ventana1, not guiGetVisible ( ventana1 ) )
end

