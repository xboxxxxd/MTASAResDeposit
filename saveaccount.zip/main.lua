-- Resource by CoolDark
database = mysql_connect( "mysql.hostfree.nl", "u309443412_moga", "kolpol55", "accounts" ) -- connectDB
if database then
	outputDebugString ('Connect')
else
	outputDebugString ("Trouble")
end

function saveAccounts () -- Save in the database
	local serial = getPlayerSerial ( source )
	local x,y,z = getElementPosition( source )
	local i = getElementInterior( source )
	local d = getElementDimension( source )
	local skin = getPedSkin ( source )
	local money = getPlayerMoney ( source )
	local health = getElementHealth ( source )
	local armor = getPedArmor ( source )
	local wanted = getPlayerWantedLevel ( source )
	local q =  mysql_query(database,"SELECT * FROM `accounts` WHERE `serial` = '".. serial .."'")
	if(mysql_num_rows(q) == 0) then
		mysql_query( database, "INSERT INTO accounts ( `serial` , x, y, z, intterior, demension, skin, money, health, armor, wanted ) VALUES ( '" .. serial .. "', " .. x .. ", " .. y .. ", " .. z .. "," .. i .. ", " .. d .. "," .. skin .. "," .. money .. ", ".. health ..", ".. armor ..", " .. wanted .. " )" )
	else
		res = mysql_query ( database, "UPDATE `accounts` SET x = ".. x ..", y =  ".. y ..", z = ".. z ..", intterior = ".. i ..", demension = ".. d ..", skin = ".. skin ..", money = ".. money ..", health = ".. health ..", armor = ".. armor ..", wanted = ".. wanted .." WHERE `serial` = '"..serial.."'")
	end
end

function loadAccounts () -- Loading from the database
	local serial = getPlayerSerial ( source )
	local result = mysql_query ( database ,"SELECT * FROM `accounts` WHERE `serial` = '"..serial.."'")
	if result then
		while true do
			local row = mysql_fetch_assoc(result)
			if not row then break end
			setElementPosition ( source, row.x, row.y, row.z)
			setElementInterior ( source, row.intterior )
			setElementDimension ( source, row.demension )
			setPedSkin ( source, row.skin )
			setPlayerMoney ( source, row.money )
			setElementHealth ( source, row.health)
			setPedArmor ( source, row.armor )
			setPlayerWantedLevel ( source, row.wanted )
			-- outputChatBox ('You were warped at latest position',source,255,255,255,true)
			break
		end
	end
end
addEventHandler ( "onPlayerJoin", getRootElement(), loadAccounts )
addEventHandler ( "onPlayerQuit", getRootElement(), saveAccounts )
