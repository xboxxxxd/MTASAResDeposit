-------------------------------------------------
--*   (c) 2015  MOGA DRIFT FREEROAM WWW.mtamoga.enjin.com     *--
--*           Script made by ssmoke         *--
-------------------------------------------------

acikmi = 0
texShader = dxCreateShader ( "texreplace.fx" )
function zaa()
	if acikmi == 0 then
		smoke = dxCreateTexture("zaa.png")
		dxSetShaderValue(texShader,"gTexture",smoke)
		engineApplyShaderToWorldTexture(texShader,"collisionsmoke")
		acikmi = 1
		msg1 = "Car Smokes"
		msg2 = "Car smokes are #ff0000disabled!"
		color = "red"
		showNotice( color,msg1,msg2 )
		--outputChatBox("#c0c0c0* Car-Smokes are #abcdefdisabled#c0c0c0!",255,255,255,true)
	elseif acikmi == 1 then
		engineRemoveShaderFromWorldTexture(texShader,"collisionsmoke")
		acikmi = 0
		msg1 = "Car Smokes"
		msg2 = "Car smokes are #00ff00enabled!"
		color = "green"
		showNotice( color,msg1,msg2 )
		--outputChatBox("#c0c0c0* Car-Smokes are #abcdefenabled#c0c0c0!",255,255,255,true)
	end	
end
bindKey("k","down",zaa)

---------------------------------------------------
-- End and Security Good luck taking this script --
---------------------------------------------------
fileDelete ("smoke.lua")
