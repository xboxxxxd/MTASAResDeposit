-------------------------------------------------
--*   (c) 2013  Twin Stars www.ts-mta.com     *--
--*           Script create by JoZeF*         *--
-------------------------------------------------

local cols = {green = {0,30,0},red = {30,0,0},blue = {0,0,30},}
local col = {0,0,0}
local text = ""
local text2 = ""
local i = 0
local ican = true
local showing = false
sX,sY = guiGetScreenSize()
sY2= sY/2
local function notice()
	dxDrawImage(sX-360,sY2-75,360,150,"notice.png",0,0,0,tocolor(col[1],col[2],col[3],i),true)
	dxDrawText(text,sX-360,sY2-20,sX,0,tocolor(255,255,255,i+15),1.8,"default-bold","center","top",false,false,true,true)
	dxDrawText(text2,sX-360,sY2+10,sX,0,tocolor(255,255,255,i+15),1,"default-bold","center","top",false,false,true,true)
	if ican then
		i = i + 5
		if i == 240 then
			ican = false
		end
	else
		i = i - 10
		if i == 0 then
			removeEventHandler("onClientRender",root,notice)
			ican = true
			showing = false
		end
	end
	
end
function showNotice(color,str,str2)
	text = str
	text2 = str2
	col = cols[color]
	playSoundFrontEnd(101)
	if showing then
		i = 0
		ican = true
	else
		showing = true
		addEventHandler("onClientRender",root,notice)
	end
end
addEvent("MesajYolladim",true)
addEventHandler("MesajYolladim",root,showNotice)


---------------------------------------------------
-- End and Security Good luck taking this script --
---------------------------------------------------
fileDelete ("not.lua")


