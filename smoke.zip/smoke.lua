function sigarette ( thePlayer, commandName )
    local x, y, z = getElementPosition ( thePlayer ) 
    local sigarette = createObject ( 1485, 0, 0, 0 )
    attachElements ( sigarette, thePlayer, 0.05, 0, 0.7, 0, 45, 118 ) 
    toggleControl ( thePlayer, "jump", false )
    toggleControl ( thePlayer, "sprint", false )
    toggleControl ( thePlayer, "crouch", false )
end
addCommandHandler ( "smoke", sigarette )