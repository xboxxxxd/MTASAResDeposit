local url = "http://www.181.fm/winamp.pls?station=181-power&style=mp3&description=Power%20181%20(Top%2040)&file=181-power.pls"

function playTheSound(x, y, z, vehicle)
	sound = playSound3D(url, x, y, z)
	if (isElement(vehicle)) then attachElements(sound, vehicle) end
end
addEvent("playTheSound", true)
addEventHandler("playTheSound", root, playTheSound)

function stopTheSound(x, y, z)
	stopSound(sound)
end
addEvent("stopTheSound", true)
addEventHandler("stopTheSound", root, stopTheSound)

-- 181 FM: http://www.181.fm/winamp.pls?station=181-power&style=mp3&description=Power%20181%20(Top%2040)&file=181-power.pls
-- The Hitz channel: http://www.in.com/music/radio/977-the-hitz-channel-15.html