function createSpeaker(thePlayer)
	local x, y, z = getElementPosition(thePlayer)
	speakerObject = createObject(2229, x, y, z-1)
    outputChatBox("You have Succesfully created a speaker!", thePlayer, 0, 250, 0)
	if (isPedInVehicle(thePlayer)) then
		local vehicle = getPedOccupiedVehicle(thePlayer)
		attachElements(speakerObject, vehicle)
		triggerClientEvent(root, "playTheSound", root, x, y, z, vehicle)
	else
		triggerClientEvent(root, "playTheSound", root, x, y, z)
	end
end
addCommandHandler("placespeaker", createSpeaker)

function deleteSpeaker(thePlayer)
	if (isElement(speakerObject)) then
		destroyElement(speakerObject)
		outputChatBox("You have Succesfully destroyed the Speaker!", thePlayer, 0, 0, 255)
                triggerClientEvent("stopTheSound", root)
	else
		outputChatBox("Speaker is not created!", thePlayer, 250, 0, 0)
	end
end
addCommandHandler("destroyspeaker", deleteSpeaker)