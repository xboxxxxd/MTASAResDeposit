------------------------------------------------
--											||
--									        ||
-- 											||
--	Private message system by NeXTreme		||
--										    ||
--										   \||/
--											\/
------------------------------------------------

function privateMessage(thePlayer,commandName,sendToName,...)
	local pmWords = { ... }
	local pmMessage = table.concat( pmWords, " " )
	if sendToName then
		if (getPlayerFromParticalName (sendToName)) then
		toPlayer = (getPlayerFromParticalName (sendToName))
			if not (toPlayer == thePlayer) then
				if not (pmMessage == "") then
					outputChatBox("#0044FF[PM]#FFFFFF Message to #FFFFFF" .. getPlayerName(toPlayer) .. "#FFFFFF: " .. pmMessage, thePlayer, 255, 255, 255, true)
					outputChatBox("#0044FF[PM]#FFFFFF Message from #FFFFFF" .. getPlayerName(thePlayer) .. "#FFFFFF: " .. pmMessage, toPlayer, 255, 255, 255, true)
				else
					outputChatBox("#0044FF[PM]#FFFFFF Invalid syntax! Usage:#FFFFFF /pm [partical player name] [message]", thePlayer, 255, 255, 255, true)
					return false
				end
			else
				outputChatBox("#0044FF[PM]#FFFFFF You cannot PM yourself#FFFFFF!", thePlayer, 255, 255, 255, true)
				return false
			end
		else
			outputChatBox("#0044FF[PM]#FFFFFF Player not found! #FFFF00(#FFFFFF"..sendToName.."#FFFF00)", thePlayer, 255, 255, 255, true)
			return false
		end
	else
		outputChatBox("#0044FF[PM]#FFFFFF Invalid syntax! Usage:#FFFFFF /pm [partical player name] [message]", thePlayer, 255, 255, 255, true)
		return false
	end
end
addCommandHandler("pm", privateMessage)


function getPlayerFromParticalName(thePlayerName)
	local thePlayer = getPlayerFromName(thePlayerName)
	if thePlayer then
		return thePlayer
	end
	for _,thePlayer in ipairs(getElementsByType("player")) do
		if string.find(string.gsub(getPlayerName(thePlayer):lower(),"#%x%x%x%x%x%x", ""), thePlayerName:lower(), 1, true) then
			return thePlayer
		end
	end
return false
end

