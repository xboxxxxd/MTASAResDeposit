 --[[
 Ghost Mode System - Hajowlah GhostMode By |S.s|SoRa
 www.gta-arab.com
 --]]
addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), function()
outputChatBox ( "#00CCFF Hajowlah Ghost Mode By #ff0000|S.s|SoRa", getRootElement(), 255, 0, 0, true )
outputChatBox ( "#FFFFFF* visit us: #0000FFhttp://www.gta-arab.com", getRootElement(), 255, 0, 0, true )
end)
function sora(player)
 local theVehicle = getPedOccupiedVehicle ( player )

		triggerClientEvent ("Ghost",player,theVehicle)
		outputChatBox ( "Ghost Mode On", player, 0, 255, 0, true )
			end

		addEventHandler ( "onVehicleStartEnter", getRootElement(), sora)
  addCommandHandler("smg",sora)

  function off(player)
 local theVehicle = getPedOccupiedVehicle ( player )

		triggerClientEvent ("Ghostoff",player,theVehicle)
		outputChatBox ( "Ghost Mode Off", player, 255, 0, 0, true )
			end

  addCommandHandler("sgoff",off)
