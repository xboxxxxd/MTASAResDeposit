 --[[
 Ghost Mode System - Hajowlah GhostMode By |S.s|SoRa
 www.gta-arab.com
 --]]
	function Ghost(theVehicle)
	for index,vehicle in ipairs(getElementsByType("vehicle")) do
		setElementCollidableWith(vehicle, theVehicle, false)
		end
		end


		addEvent("Ghost",true)
		addEventHandler("Ghost",getRootElement(),Ghost)


			function Ghostoff(theVehicle)
	for index,vehicle in ipairs(getElementsByType("vehicle")) do
		setElementCollidableWith(vehicle, theVehicle, true)
		end
		end


		addEvent("Ghostoff",true)
		addEventHandler("Ghostoff",getRootElement(),Ghostoff)

