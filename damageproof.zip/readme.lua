--[[
	DAMAGEPROOF VEHICLES by DZEK.
	
	You are free to copy and use it,
	you are free to edit this one to suit your needs
	
	It would be nice if you leave this readme.
	
	http://dzek.metal.info/mta
	
	msn:   kns1@o2.pl
	mail:  kns1@o2.pl
	skype: dzek69
	gg:    2928054
	www:   dzek.metal.info/mta

	Thanks.
	
	Jacek Nowacki a.k.a. DZEK
]]--