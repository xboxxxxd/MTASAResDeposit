local vehs = getElementsByType("vehicle")
for key, val in ipairs(vehs) do
	setVehicleDamageProof(val, true)
end

addEvent("onVehicleSpawn")
addEventHandler("onVehicleSpawn", getRootElement(), function()
	setVehicleDamageProof(source, true)
end)

setTimer(function()
  local vehs = getElementsByType('vehicle')
  for key,val in ipairs(vehs) do
    local ed = getElementData(val, "spawnedEventTriggered")
    if (ed ~= true) then
      setElementData(val, "spawnedEventTriggered", true)
      triggerEvent("onVehicleSpawn", val)
    end
  end
end, 500, 0)