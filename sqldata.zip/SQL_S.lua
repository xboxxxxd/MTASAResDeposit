﻿--[[
	\\ By 3ash8Alshrq //
	Features:
	Save data in serial player via SQL.
	And you can remove data.
	
	Exported functions:
	bool setPlayerSerialData( player thePlayer, string key, string value )
	string getPlayerSerialData( player thePlayer, string key )
	bool removePlayerSerialData( player thePlayer, string key )
	table getAllPlayerSerialData( player thePlayer )
]]

addEventHandler( 'onResourceStart', resourceRoot,
	function( )
		executeSQLQuery( 'CREATE TABLE IF NOT EXISTS SerialData ( serialPlayer TEXT, key STRING, value TEXT )' )
	end
)

aType =
{
	[ 'number' ] = true ;
	[ 'string' ] = true ;
}

function setPlayerSerialData( player, key, value )
	if not isElement( player ) then
		return
	end
	if type( key ) == 'string' and aType[ type( value ) ] then
		if getPlayerSerialData( player, key ) then
			executeSQLQuery( 'UPDATE SerialData SET serialPlayer = ?, key = ?, value = ?', getPlayerSerial( player ), key, value )
			return true
		else
			executeSQLQuery( 'INSERT INTO SerialData( serialPlayer, key, value ) VALUES( ?, ?, ? )', getPlayerSerial( player ), key, value )
			return true
		end
	end
end

function getPlayerSerialData( player, key )
	if not isElement( player ) then
		return
	end
	if type( key ) == 'string' then
		result = executeSQLQuery( 'SELECT value FROM SerialData WHERE key = ? AND serialPlayer = ?', key, getPlayerSerial( player ) )
	end
	if result and type( result ) == 'table' and #result > 0 then
		if result[ 1 ][ 'value' ] then
			return result[ 1 ][ 'value' ]
		else
			return false
		end
	end
	return false
end

function removePlayerSerialData( player, key )
	if not isElement( player ) then
		return
	end
	if type( key ) == 'string' then
		if getPlayerSerialData( player, key ) then
			executeSQLQuery( 'DELETE FROM SerialData WHERE key = ? AND serialPlayer = ?', key, getPlayerSerial( player ) )
			return true
		end
	end
end

function getAllPlayerSerialData( player )
	if not isElement( player ) then
		return
	end
	if type( key ) == 'string' then
		aResult = executeSQLQuery( 'SELECT * FROM SerialData WHERE serialPlayer = ?', getPlayerSerial( player ) )
	end
	if aResult and type( aResult ) == 'table' and #aResult > 0 then
		return aResult[ 1 ]
	else
		return false
	end
	return false
end