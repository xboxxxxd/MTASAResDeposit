
addEventHandler("onClientResourceStart",resourceRoot,
function()
    triggerServerEvent("onDownloadFinish",localPlayer)
end )