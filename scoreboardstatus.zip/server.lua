
exports.scoreboard:addScoreboardColumn('status')
 
function onJoin()
setElementData ( source, "status", "Downloading" )
end
addEventHandler("onPlayerJoin",root,onJoin)
 
function onDownloadFinish()
setElementData ( client, "status", "Playing" )
end
addEvent("onDownloadFinish",true)
addEventHandler("onDownloadFinish",root,onDownloadFinish)