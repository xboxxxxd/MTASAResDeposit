
function rdx ( message )
    removeEventHandler ( "onClientRender", getRootElement(  ), dx )
    function dx(  )
    dxDrawText ( " Admin :", 13.0, 167.0, 55.0, 182.0, tocolor ( 0, 255, 0, 0 ), 1.2, "black_jack.ttf", "left", "top", false, false, false )
    dxDrawText ( message, 75.0, 168.0, 799.0, 224.0, tocolor(math.random(100,255),math.random(100,255),math.random(100,255)), 1.2, "black_jack.ttf", "left", "top", false, false, false )
    end
    addEventHandler("onClientRender", getRootElement(  ), dx )
end
addEvent ( "sora", true )
addEventHandler ( "sora", getRootElement(  ), rdx )
bindKey ( "i", "down", "chatbox", "Admin" )


addEventHandler ( "onClientResourceStart", resourceRoot, function (  )
triggerServerEvent ( "SetMessage", localPlayer )
end
)
