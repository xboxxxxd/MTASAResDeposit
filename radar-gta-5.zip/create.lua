--casa CJ
createBlip ( 2495.38672, -1688.48108, 13.83304, 15 )

--pista aeroporto1
createBlip ( -1513.82837, -21.41595, 14.14089, 57 )          

--pista aeroporto2
createBlip ( 1740.79395, -2544.96704, 13.54688, 57 )

--pista aeroporto3
createBlip ( 1436.59033, 1517.56885, 10.82031, 57 )

--pista aeroporto4
createBlip ( 217.73091, 2503.60083, 16.48438, 57 )

--Oficina
createBlip ( -2038.509, 171.297, 28.836, 27 )

fileDelete ("create.lua")