local minuteDelay = get ("realtime.minuteDelay")
setMinuteDuration (minuteDelay)

local hour = get ("realtime.initialHour")
local minute = get ("realtime.initialMinute")
setTime (hour,minute)