----------------- Anti-Bounce ----------------------
-- * This resource/script is created by Z://Arezu and -rG//MegaDreams.
-- * Do not redistribuate without permission.
-- *
-- * Copyright (C) 2014 Z://Arezu and -rG//MegaDreams.
-- *
-- * Licensed under the Apache License, Version 2.0 (the "License");
-- * you may not use this file except in compliance with the License.
-- * You may obtain a copy of the License at
-- *
-- *     http://www.apache.org/licenses/LICENSE-2.0
-- *
-- * Unless required by applicable law or agreed to in writing, software
-- * distributed under the License is distributed on an "AS IS" BASIS,
-- * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- * See the License for the specific language governing permissions and
-- * limitations under the License.
---------------------------------------------------

--[[------------------
* Anti-Bounce v2.1.0
* File: s_utils.lua
*
* We highly discourage
* directly editing the
* scripts. Please use
* the customization
* possibilities.
--------------------]]

----------------------
-- Variables
----------------------

Utils = {}
Utils = setmetatable({},{__index = Utils})

----------------------
-- Functions/Events
----------------------

function Utils:outputMessageToAdmins(lMessage,...)
	for _,lPlayer in pairs(getElementsByType("player")) do
		if(isObjectInACLGroup("user."..lPlayer:getAccount():getName(),ACLGroup.get("Admin"))) then
			outputChatBox(lMessage,lPlayer,...)
		end
	end
	
	outputDebugString(lMessage:gsub("#%x%x%x%x%x%x",""),3)
end