----------------- Anti-Bounce ----------------------
-- * This resource/script is created by Z://Arezu and -rG//MegaDreams.
-- * Do not redistribuate without permission.
-- *
-- * Copyright (C) 2014 Z://Arezu and -rG//MegaDreams.
-- *
-- * Licensed under the Apache License, Version 2.0 (the "License");
-- * you may not use this file except in compliance with the License.
-- * You may obtain a copy of the License at
-- *
-- *     http://www.apache.org/licenses/LICENSE-2.0
-- *
-- * Unless required by applicable law or agreed to in writing, software
-- * distributed under the License is distributed on an "AS IS" BASIS,
-- * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- * See the License for the specific language governing permissions and
-- * limitations under the License.
---------------------------------------------------

--[[------------------
* Anti-Bounce v2.1.0
* File: s_core.lua
*
* We highly discourage
* directly editing the
* scripts. Please use
* the customization
* possibilities.
--------------------]]

----------------------
-- Variables
----------------------

Core = {}
Core = setmetatable({},{__index = Core})

Core.g_Root = getRootElement()
Core.g_ThisResource = Resource:getThis()
Core.g_ResourceRoot = Core.g_ThisResource:getRootElement()

Core.VERSION = 210

----------------------
-- Functions/Events
----------------------

function Core:onResourceStart()
	Settings:loadSettings()
	Updater:setup()
	
	Statistics:setup()
end
addEventHandler("onResourceStart",Core.g_ResourceRoot,Core.onResourceStart)