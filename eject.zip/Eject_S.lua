function ejectPlayers(player)
	local vehicle = getPedOccupiedVehicle(player)
	if vehicle then
		local driver = getVehicleOccupant(vehicle, 0)
		local passenger1 = getVehicleOccupant(vehicle, 1)
		local passenger2 = getVehicleOccupant(vehicle, 2)
		local passenger3 = getVehicleOccupant(vehicle, 3)
		local passenger4 = getVehicleOccupant(vehicle, 4)
		if driver then
			if driver == player then
				if passenger1 or passener2 or passenger3 or passenger4 then
					if passenger1 then
						removePedFromVehicle(passenger1)
						outputChatBox("#FF007F[EJECT] #FFFFFFDriver of the vehicle #FF007F[#FFFFFF"..getPlayerName(player).."#FF007F] #FFFFFFhas ejected you from vehicle.", passenger1, 255, 255, 255, true)
					end
					if passenger2 then
						removePedFromVehicle(passenger2)
						outputChatBox("#FF007F[EJECT] #FFFFFFDriver of the vehicle #FF007F[#FFFFFF"..getPlayerName(player).."#FF007F] #FFFFFFhas ejected you from vehicle.", passenger2, 255, 255, 255, true)
					end
					if passenger3 then
						removePedFromVehicle(passenger3)
						outputChatBox("#FF007F[EJECT] #FFFFFFDriver of the vehicle #FF007F[#FFFFFF"..getPlayerName(player).."#FF007F] #FFFFFFhas ejected you from vehicle.", passenger3, 255, 255, 255, true)
					end
					if passenger4 then
						removePedFromVehicle(passenger4)
						outputChatBox("#FF007F[EJECT] #FFFFFFDriver of the vehicle #FF007F[#FFFFFF"..getPlayerName(player).."#FF007F] #FFFFFFhas ejected you from vehicle.", passenger4, 255, 255, 255, true)
					end
					outputChatBox("#FF007F[EJECT] #FFFFFFYou have ejected all passengers.", player, 255, 255, 255, true)
				else
					outputChatBox("#FF007F[EJECT] #FFFFFFYou are alone in vehicle.", player, 255, 255, 255, true)
				end
			else
				outputChatBox("#FF007F[EJECT] #FFFFFFYou need to be driver of this vehicle to use this command.", player, 255, 255, 255, true)
			end
		else
			outputChatBox("#FF007F[EJECT] #FFFFFFYou need to be driver of this vehicle to use this command.", player, 255, 255, 255, true)
		end
	else
		outputChatBox("#FF007F[EJECT] #FFFFFFYou need to be in vehicle to use this command.", player, 255, 255, 255, true)
	end
end
addCommandHandler("eject", ejectPlayers)