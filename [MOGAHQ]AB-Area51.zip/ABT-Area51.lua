			local Turm = createObject(3279, 87, 1726, 1, 0, 0, 0)
			local Turm2 = createObject(3279, 87, 1749, 1, 0, 0, 0)

function Rolges (Player)
	moveObject(Turm, 7000, 87, 1726, 16.8, 0, 0, 0)
	moveObject(Turm2, 7000, 87, 1749, 16.8, 0, 0, 0)
	playSoundFrontEnd ( 32 )
			
			
end
addCommandHandler ("AB51UP", Rolges) 

function Rolgesdown (Player)
	moveObject(Turm, 7000, 87, 1726, 1, 0, 0, 0)
	moveObject(Turm2, 7000, 87, 1749, 1, 0, 0, 0)
	playSoundFrontEnd ( 32 )
		
		
end
addCommandHandler ("AB51DOWN", Rolgesdown)
