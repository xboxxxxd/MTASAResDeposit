-- clientside

function createKeypad()

	local sWidth, sHeight = guiGetScreenSize()
 

	local Width,Height = 142,276
	local X = (sWidth/2) - (Width/2)
	local Y = (sHeight/2) - (Height/2)
	keypadWindow = guiCreateWindow(X,Y,Width,Height,"Keypad",false)

	addEventHandler("onClientGUIClick",keypadWindow,processKeypadClicks,true)
 

	guiWindowSetSizable(keypadWindow,false)
 

	keypadButton1 = guiCreateButton(13,68,37,36,"1",false,keypadWindow)
	keypadButton2 = guiCreateButton(53,68,37,36,"2",false,keypadWindow)
	keypadButton3 = guiCreateButton(93,68,37,36,"3",false,keypadWindow)
	keypadButton4 = guiCreateButton(13,108,37,36,"4",false,keypadWindow)
	keypadButton5 = guiCreateButton(53,108,37,36,"5",false,keypadWindow)
	keypadButton6 = guiCreateButton(93,108,37,36,"6",false,keypadWindow)
	keypadButton7 = guiCreateButton(13,148,37,36,"7",false,keypadWindow)
	keypadButton8 = guiCreateButton(53,148,37,36,"8",false,keypadWindow)
	keypadButton9 = guiCreateButton(93,148,37,36,"9",false,keypadWindow)
	keypadButtonAsterix = guiCreateButton(13,188,37,36,"*",false,keypadWindow)
	keypadButton0 = guiCreateButton(53,188,37,36,"0",false,keypadWindow)
	keypadButtonHash = guiCreateButton(93,188,37,36,"#",false,keypadWindow)
	keypadButtonExit = guiCreateButton(13,228,37,36,"Exit",false,keypadWindow)
	keypadButtonEnter = guiCreateButton(53,228,37,36,"Enter",false,keypadWindow)
	keypadButtonClear = guiCreateButton(93,228,37,36,"Clear",false,keypadWindow)
 

	keypadGridlistDisplay = guiCreateGridList(13,25,117,33,false,keypadWindow)
	guiGridListSetSelectionMode(keypadGridlistDisplay,2)
	guiSetAlpha(keypadGridlistDisplay,0.6)

	keypadLabelDisplay = guiCreateLabel(14,26,115,30,"SXG KeyPad Loaded",false,keypadWindow)
	guiLabelSetColor(keypadLabelDisplay,255,000,000)
	guiLabelSetVerticalAlign(keypadLabelDisplay,"center")
	guiLabelSetHorizontalAlign(keypadLabelDisplay,"center",false)
 
	guiSetVisible(keypadWindow,false)
end
 

addEventHandler("onClientResourceStart",getResourceRootElement(getThisResource()),createKeypad)

function updateDisplay(text)

	if text then

		if tonumber(text) or text == "*" or text == "#" then
			guiSetText(keypadLabelDisplay,guiGetText(keypadLabelDisplay) .. text)

		else
			guiSetText(keypadLabelDisplay,text)
		end	

	else
		guiSetText(keypadLabelDisplay,"")
	end
end

function processKeypadClicks(button,state)
	if button == "left" and state == "up" then

		if getElementType(source) == "gui-button" then

			triggerEvent("onKeypadButtonClicked",source,getElementData(keypadWindow,"keypadID"))
		end
	end
end

addEvent("onKeypadButtonClicked",false)
addEventHandler("onKeypadButtonClicked",root,
	function(keypadID)

		if guiGetText(keypadLabelDisplay) == "SXG KeyPad Loaded" or guiGetText(keypadLabelDisplay) == "Error." then
			updateDisplay()
		end
 
 

		if guiGetText(source) == "Clear" then

			updateDisplay()
 

		elseif guiGetText(source) == "Enter" then

			local code = guiGetText(keypadLabelDisplay)
 

			if code then

				triggerServerEvent("verifyKeypadCode",getLocalPlayer(),code,keypadID)
			end
 

		elseif guiGetText(source) == "Exit" then

			guiSetVisible(keypadWindow,false)
			updateDisplay("Enter Keycode.")
			showCursor(false,false)
 

		else
			updateDisplay(guiGetText(source))	
		end
	end
)

addEvent("onKeypadVerificationSuccessful",true)
addEventHandler("onKeypadVerificationSuccessful",root,
	function()

		guiSetVisible(keypadWindow,false)
		updateDisplay("SXG KeyPad Loaded")
		showCursor(false,false)
	end
)

addEvent("onKeypadVerificationFailed",true)
addEventHandler("onKeypadVerificationFailed",root,
	function()

		updateDisplay("Error")
	end
)

addCommandHandler("gate",function()
	guiSetVisible(keypadWindow,true)
	showCursor(true,true)
	setElementData(keypadWindow,"keypadID","GateKeypadCode")
end)

addEventHandler("onKeypadVerificationSuccessful",root,

	function(keypadID)

		local gate = getElementByID(keypadID)
 

		if gate then

			local x = tonumber(getElementData(gate,"newPosX"))
			local y = tonumber(getElementData(gate,"newPosY"))
			local z = tonumber(getElementData(gate,"newPosZ"))
 

			moveObject(gate,1500,x,y,z)
 

			x = tonumber(getElementData(gate,"posX"))
			y = tonumber(getElementData(gate,"posY"))
			z = tonumber(getElementData(gate,"posZ"))	
 

			setTimer(moveObject,5000,1,gate,1500,x,y,z)
		end
	end
)