function play1() 
local sound = playSound3D("http://www.hot108.com/hot108.asx", 214.34786987305, 1908.0185546875, 17.640625, true)
	setSoundMaxDistance (sound, 175)
	end
 addEventHandler ( "onClientResourceStart", getResourceRootElement ( getThisResource () ), play1 )