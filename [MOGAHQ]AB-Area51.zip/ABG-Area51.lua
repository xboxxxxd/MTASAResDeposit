checkGateMarker = createMarker ( 216.22926330566, 1875.0806884766, 7.4616560935974, "corona", 10.0, 0, 0, 255, 0 )
function onPoliceShapeHit ( thePlayer, matchingDimension )
	if ( getElementType ( thePlayer ) == "player" ) then
		outputChatBox ( "Welcome inside Area51 Underground Base.", thePlayer, 0, 0, 255 )
	end
end
addEventHandler ( "onColShapeHit", policeColShape, onPoliceShapeHit )

function createGate ()
	gatePolice = createObject ( 16775, 210.62886047363, 1875.3189697266, 12.626561164856 )
end
addEventHandler ( "onResourceStart", getResourceRootElement ( getThisResource () ), createGate )


function gateCheckingTeam ( thePlayer, matchingDimension )
	moveObject ( gatePolice, 16775, 200.62886047363, 1875.3189697266, 12.626561164856  )
end
addEventHandler ( "onMarkerHit", checkGateMarker, gateCheckingTeam )

function onLeave ( thePlayer, matchingDimension )
	setTimer ( movingBackPolice, 3000, 1, thePlayer )
end
addEventHandler ( "onMarkerLeave", checkGateMarker, onLeave )

function movingBackPolice ()
	moveObject ( gatePolice, 3000, 210.62886047363, 1875.3189697266, 12.626561164856 )
end