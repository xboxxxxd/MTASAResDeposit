-- serverside

local keypadCodes = {
	["GateKeypadCode"] = "Your PassCode"
}
addEvent("verifyKeypadCode",true)
addEventHandler("verifyKeypadCode",root,function(code,keypadID)
	if code then

		if code == keypadCodes[keypadID] then

			triggerClientEvent(client,"onKeypadVerificationSuccessful",client,keypadID)
		else

			triggerClientEvent(client,"onKeypadVerificationFailed",client,keypadID)
		end
	end
end)