function removeHEX(oldNick,newNick)
	local name = getPlayerName(source)
	if newNick then
		name = newNick
	end
	if name:find("#%x%x%x%x%x%x") then
		local name = name:gsub("#%x%x%x%x%x%x","")
		if name:len() > 0 then
			setPlayerName(source,name)
		else
			setPlayerName(source,"Noob_"..tostring(math.random(100)))
		end
		if newNick then
			cancelEvent()
		end
	end	
end
addEventHandler("onPlayerJoin",root,removeHEX)
addEventHandler("onPlayerChangeNick",root,removeHEX)

function startup()
	for k, v in ipairs(getElementsByType("player")) do
		local name = getPlayerName(v)
		if name:find("#%x%x%x%x%x%x") then
			local name = name:gsub("#%x%x%x%x%x%x","")
			if name:len() > 0 then
				setPlayerName(v,name)
			else
				setPlayerName(v,"Noob_"..tostring(math.random(100)))
			end
		end
	end
end
addEventHandler("onResourceStart",resourceRoot,startup)