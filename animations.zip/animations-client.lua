local resX, resY = guiGetScreenSize()

function makeAnimationGUI()
	animationWindow = guiCreateWindow(resX/2-150,resY/2-200,300,400,"Animations",false)
	guiSetVisible(animationWindow,false)
	animationCategoryList = guiCreateGridList(0.01,0.1,0.45,0.7,true,animationWindow)
	animationList = guiCreateGridList(0.48,0.1,0.45,0.7,true,animationWindow)
	column1 = guiGridListAddColumn(animationCategoryList,"Category",0.8)
	column2 = guiGridListAddColumn(animationList,"Animation",0.8)
	stopButton = guiCreateButton(0.01,0.8,0.9,0.3,"Stop Animation",true,animationWindow)
	addEventHandler("onClientGUIClick",stopButton,function() setPedAnimation(getLocalPlayer(),nil,nil) end)
		for k, v in ipairs (getElementsByType("animationCategory")) do
			local row = guiGridListAddRow(animationCategoryList)
			guiGridListSetItemText(animationCategoryList,row,column1,getElementID(v),false,false)
		end
addEventHandler("onClientGUIClick",animationCategoryList,getAnimations)
addEventHandler("onClientGUIClick",animationList,setAnimation)
end
addEventHandler("onClientResourceStart",getResourceRootElement(getThisResource()),makeAnimationGUI)

function toggleVisible()
	if (guiGetVisible(animationWindow) == false) then
		guiSetVisible(animationWindow,true)
		showCursor(true)
	else
		guiSetVisible(animationWindow,false)
		showCursor(false)
	end
end
bindKey("F5","down",toggleVisible)

function getAnimations()
	selectedCategory = guiGridListGetItemText(animationCategoryList,guiGridListGetSelectedItem(animationCategoryList),1)
		if (selectedCategory ~= "") then
			guiGridListClear(animationList)
				for k, v in ipairs (getElementChildren(getElementByID(selectedCategory))) do
					local row = guiGridListAddRow(animationList)
					guiGridListSetItemText(animationList,row,column1,getElementID(v),false,false)
				end
		end
		if (selectedCategory == "") then
			guiGridListClear(animationList)
		end
end

function setAnimation()
	selectedAnimation = guiGridListGetItemText(animationList,guiGridListGetSelectedItem(animationList),1)
		if (selectedAnimation ~= "") then
			if (not isPlayerDead(getLocalPlayer())) then
				if (isPedInVehicle(getLocalPlayer()) == false) then
					local animationBlock = getElementData(getElementByID(selectedAnimation),"block")
					local animationID = getElementData(getElementByID(selectedAnimation),"code")
					triggerServerEvent("setAnimation",getLocalPlayer(),animationBlock,animationID)
				else
					outputChatBox("You cannot use animations while in a vehicle.",255,0,0)
				end
			else
				outputChatBox("You cannot use animations while you are dead.",255,0,0)
			end
		end
end