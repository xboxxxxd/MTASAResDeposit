-------------------------------
-------------by---------------
----------MOGA------------
-------------------------------

function animationCommand ( source )
setPedAnimation ( source, "ped", "SEAT_idle", -1, true, false, false )
outputChatBox("Type /up to get up", source, 0, 0, 255 )
end
addCommandHandler ( "sit", animationCommand )

function animationCommand2 ( source )
setPedAnimation ( source )
end
addCommandHandler ( "up", animationCommand2 )


