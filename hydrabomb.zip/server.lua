
function bomb ( player )
local car = getPedOccupiedVehicle ( player )
local x, y, z = getElementPosition(player)
	if (getElementModel(car) == 520) then
      		outputChatBox ( "Luftschlag ausgefuehrt!", player )
		setTimer ( AirstrikeThrow, 51, 1, player )
	end


end 
addCommandHandler ( "jetbomb", bomb )


function AirstrikeThrow ( player, x, y, z )

	triggerClientEvent ( getRootElement(), "AirstrikeThrowDo", getRootElement(), airStrikeTrash, player )
end