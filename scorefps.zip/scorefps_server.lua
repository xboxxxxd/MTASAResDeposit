addEventHandler("onResourceStart",getResourceRootElement(getThisResource()),
	function()
		call(getResourceFromName("scoreboard"),"addScoreboardColumn","fps")
	end
)