--[[
// copyrights //
Resource Starter System by SoRa
Notice : needs admin rights
// copyrights //
--]]

-- // Settings //
allowedGroup = get("allowedGroup")
autoRemover = get("autoRemover")
-- // Settings //

-- resources name grabber
addEventHandler("onResourceStart",root,
    function (res)
	    if res ~= getThisResource() then -- if the started resource is not this resource
	       if getResourceInfo ( res, "type" ) ~= "map" then -- if the started resource isn't map
            local rNode = xmlLoadFile("resources.xml") or xmlCreateFile("resources.xml","resources") -- load resources.xml or create it if not exist
		    	for i,node in ipairs(xmlNodeGetChildren(rNode)) do -- get all children of resources.xml
		          if xmlNodeGetValue(node) == getResourceName(res) then return end -- if the started resource exist don't add it again
				end
           xmlNodeSetValue (xmlCreateChild ( rNode, "resource"), ""..getResourceName(res).."" ) -- create xml child with the name of started resource
           xmlSaveFile(rNode)
            xmlUnloadFile(rNode)
			triggerClientEvent(source,"refresh",source)
		end
		    end
    end
)
-- resources starter * using resource name *
addEventHandler("onResourceStart",getResourceRootElement(getThisResource()),
    function ()
		local xml = xmlLoadFile("resources.xml") -- load resources.xml
		  if xml then -- if resources.xml loaded
              for i,node in ipairs(xmlNodeGetChildren(xml)) do -- get all children of resources.xml
		      startResource (getResourceFromName(xmlNodeGetValue(node))) -- start them all
		      -- outputChatBox("Resources started",root,255,255,255,true)
		  end
        xmlUnloadFile(xml)
	          end
	end
)
-- stopped resources remover
addEventHandler("onResourceStop",root,
    function (res)
	   if res ~= getThisResource() and autoRemover == "true" then -- if the stopped resource is not this resource , and auto remover is enabled
          local rNode = xmlLoadFile("resources.xml") -- load resources.xml
		    for i,node in ipairs(xmlNodeGetChildren(rNode)) do -- get all children of resources.xml
		        if xmlNodeGetValue(node) == getResourceName(res) then -- if the started resource is exist in the children
		       xmlDestroyNode(node) -- destroy it
                 xmlSaveFile(rNode)
                  xmlUnloadFile(rNode)
				  triggerClientEvent(source,"refresh",source)
	    end
		    end
			     end
	end
)

-- resource lister * for the gui window *
addEvent("getChildren",true)
addEventHandler("getChildren",root,
    function ()
	children = {}
		local xml = xmlLoadFile("resources.xml") -- load resources.xml
		if xml then
	        for i,node in ipairs(xmlNodeGetChildren(xml)) do -- get all children of resources.xml
            table.insert(children,xmlNodeGetValue(node))
			end
               for i,v in ipairs(children) do -- get all children in table
		        triggerClientEvent(source,"addChildren",source,v)
                  xmlUnloadFile(xml)
				end
		end
	end
)
-- resource remover * using the gui window *
addEvent("remove",true)
addEventHandler("remove",root,
    function (resname)
        local rNode = xmlLoadFile("resources.xml") -- load resources.xml
		for i,node in ipairs(xmlNodeGetChildren(rNode)) do -- get all children of resources.xml
		      if xmlNodeGetValue(node) == resname then -- if the resource is exist in the children
		       xmlDestroyNode(node) -- destroy it
			     xmlSaveFile(rNode)
                 xmlUnloadFile(rNode)
				  if autoRemover == "true" then
			      stopResource (getResourceFromName(resname))
				  end
	    end
			   end
	end
)
-- resource add by the name * using the gui window *
addEvent("add",true)
addEventHandler("add",root,
    function (newRes)
     local rNode = xmlLoadFile("resources.xml")
        xmlNodeSetValue (xmlCreateChild ( rNode, "resource"), ""..newRes.."" ) -- create xml child with the name of resource
        xmlSaveFile(rNode)
        xmlUnloadFile(rNode)
	end
)

--  Resource Starter Systm window
addCommandHandler("rss",
function (player)
    if isObjectInACLGroup("user."..getAccountName(getPlayerAccount(player)),aclGetGroup(allowedGroup)) then
		triggerClientEvent(player,"show_rss",player)
	else
	   outputChatBox ("* RSS: You Don't Have Permission For This Command", player, 255, 0, 0, true)
    end
end)

