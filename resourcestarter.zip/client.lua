--[[
// copyrights //
Resource Starter System by SoRa
Notice : needs admin rights
// copyrights //
--]]

GUIEditor = {
    button = {},
    window = {},
}

rssWin = guiCreateWindow(151, 52, 508, 434, "Resource Starter System", false)
guiSetVisible(rssWin,false)
guiWindowSetSizable(rssWin, false)


list = guiCreateGridList(23, 51, 463, 321, false, rssWin)
guiGridListSetSelectionMode(list,2)
column = guiGridListAddColumn( list, "Startup resources list", 0.89 )
x = guiCreateButton(471, 22, 23, 21, "X", false, rssWin)
guiSetProperty(x, "NormalTextColour", "FFFF0000")

remove = guiCreateButton(204, 382, 94, 38, "Remove", false, rssWin)
guiSetProperty(remove, "NormalTextColour", "FFFF0000")
add = guiCreateButton(61, 383, 94, 38, "Add", false, rssWin)
guiSetProperty(add, "NormalTextColour", "FF00FF00")
refresh = guiCreateButton(336, 382, 94, 38, "Refresh", false, rssWin)
guiSetProperty(refresh, "NormalTextColour", "FFFFEA00")

addWin = guiCreateWindow(304, 222, 240, 165, "Add resource to startup list", false)
guiSetVisible(addWin,false)
guiWindowSetSizable(addWin, false)
edit = guiCreateEdit(34, 53, 175, 36, "", false, addWin)
label = guiCreateLabel(38, 28, 115, 20, "Resource Name :", false, addWin)
add_addWin = guiCreateButton(32, 110, 68, 39, "Add", false, addWin)
guiSetProperty(add_addWin, "NormalTextColour", "FFAAAAAA")
cancel = guiCreateButton(131, 110, 68, 39, "Cancel", false, addWin)
guiSetProperty(cancel, "NormalTextColour", "FFAAAAAA")


addEvent("show_rss",true)
addEventHandler("show_rss",root,
    function ()
	guiSetVisible(rssWin,true)
	showCursor(true)
	clear()
	triggerServerEvent ("getChildren", getLocalPlayer())
	end
)


    function clear()
guiGridListClear (list)
    end


addEvent("refresh",true)
addEventHandler("refresh",root,
    function ()
    clear()
    triggerServerEvent ("getChildren", getLocalPlayer())
	end
)

addEvent("addChildren",true)
addEventHandler("addChildren",root,
    function (v)
    guiGridListSetItemText ( list, guiGridListAddRow ( list ), column,v, false, false )
	end
)

function click()
resname = guiGridListGetItemText ( list, guiGridListGetSelectedItem ( list ), 1 )
end
addEventHandler ( "onClientGUIClick", list, click )

function onGuiClick (button, state, absoluteX, absoluteY)
	if (source == refresh) then
	clear()
    triggerServerEvent ("getChildren", getLocalPlayer())
	elseif (source == remove) then
	triggerServerEvent ("remove", getLocalPlayer(), resname)
	clear()
    triggerServerEvent ("getChildren", getLocalPlayer())
	elseif (source == add) then
	guiSetVisible(addWin,true)
	guiBringToFront ( addWin )
	showCursor(true)
	elseif (source == add_addWin) then
	local newRes = guiGetText ( edit )
	triggerServerEvent("add", getLocalPlayer(), newRes)
	guiSetVisible(addWin,false)
	clear()
    triggerServerEvent ("getChildren", getLocalPlayer())
	elseif (source == x) then
	guiSetVisible(rssWin,false)
	showCursor(false)
	elseif (source == cancel) then
	guiSetVisible(addWin,false)
     end
end
addEventHandler ("onClientGUIClick", getRootElement(), onGuiClick)



