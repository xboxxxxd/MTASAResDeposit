function ebisue ( hitPlayer, commandName, posX, posY, posZ )
fadeCamera(hitPlayer, false)
if isPedInVehicle (hitPlayer) then
		local vehicle = getPedOccupiedVehicle(hitPlayer)
		setVehicleFrozen(vehicle, true)
        setTimer(setVehicleFrozen, 1300, 1, vehicle, false)
		setTimer(fadeCamera, 1000, 1, hitPlayer, true)
        setTimer(setElementPosition, 1000, 1, vehicle,-938.1,508.1,14.1)
    else
        setElementPosition ( hitPlayer,-938.1,508.1,14.1)
		setTimer(fadeCamera, 1000, 1, hitPlayer, true)
    end
end
addCommandHandler ( "ebisue", ebisue  )	

function ebisues ( hitPlayer, commandName, posX, posY, posZ )
fadeCamera(hitPlayer, false)
if isPedInVehicle (hitPlayer) then
		local vehicle = getPedOccupiedVehicle(hitPlayer)
		setVehicleFrozen(vehicle, true)
        setTimer(setVehicleFrozen, 1300, 1, vehicle, false)
		setTimer(fadeCamera, 1000, 1, hitPlayer, true)
        setTimer(setElementPosition, 1000, 1, vehicle,-938.1,508.1,2014.1)
    else
        setElementPosition ( hitPlayer,-938.1,508.1,2014.1)
		setTimer(fadeCamera, 1000, 1, hitPlayer, true)
    end
end
addCommandHandler ( "ebisues", ebisues  )	