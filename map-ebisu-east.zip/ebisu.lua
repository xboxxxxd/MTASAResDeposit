function ebisue()
	txd = engineLoadTXD ( "1.txd" )
		engineImportTXD ( txd, 2603 )
	col = engineLoadCOL ( "1.col" )
	dff = engineLoadDFF ( "1.dff", 0 )
	engineReplaceCOL ( col, 2603 )
	engineReplaceModel ( dff, 2603 )
	engineSetModelLODDistance(2603, 2000)
end

function chat()
		outputChatBox('Ebisu East', player, 0, 255, 0)
		outputChatBox('Models By JC NEGRO .', player, 0, 255, 0)
		outputChatBox('Aportado por [ToR]MaCrO', player, 0, 255, 0)
		outputChatBox('Conversion a MTA por [GT]Scarface & [GT]zorrigas.', player, 0, 255, 0)
		outputChatBox('www.gtagamingchile.com.', player, 0, 255, 0)
end

setTimer ( ebisue, 1000, 1)
addCommandHandler("ebisue",ebisue)
addCommandHandler("ebisues",ebisue)
addCommandHandler("mapas",ebisue)
addCommandHandler("ebisue",chat)

addEventHandler("onClientResourceStop", getResourceRootElement(getThisResource()),
	function()
		engineRestoreCOL(2603)
		engineRestoreModel(2603)
		destroyElement(dff)
		destroyElement(col)
		destroyElement(txd)
	end
)