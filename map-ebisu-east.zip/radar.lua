	
	rpBlipOne = createBlip ( -765.1, 689.9, 16.7, 33 ) -- sf blip
	--rpBlipTwo = createBlip ( x, y, z, 27 )
	