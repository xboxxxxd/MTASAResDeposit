weaponType = {35, 27, 22, 23, 24, 28, 29, 30, 31, 32, 34, 38} -- This is the list of allowed weapon IDs. Please check http://wiki.mtasa.com/wiki/Weapons for weapon IDs.
createCommand = {"vehweap", "vehicleweapon"} -- This is the list of commands to use the vehicle weapon system.
requiredRights = {"XDM-HQ", "energy", "Admin", "Console"} -- This is the list of ACL Groups which are allowed to use the vehicle weapon system. You can add "Everyone" ACL Group to the list or empty the list to allow everyone to use it.
fireDelay = 100 -- Delay between each fire in miliseconds.
defaultFireDelay = false -- Set to 'true' to use the default fire delay. When set to default fire delay, sometimes the weapon will stop to shoot because of reloading ammo.

-- Do not modify the lines below, unless you know what you are doing.
if #weaponType > 0 and #createCommand > 0 and requiredRights and fireDelay then
	createServerFunctions(true)
else
	createServerFunctions(false)
end